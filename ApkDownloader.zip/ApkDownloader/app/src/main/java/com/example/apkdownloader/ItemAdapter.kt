package com.example.apkdownloader

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.apkdownloader.databinding.ItemDownloadBinding

class ItemAdapter(
    private val items: List<Item>,
    private val onAction: (Item) -> Unit
) : RecyclerView.Adapter<ItemAdapter.VH>() {

    class VH(val b: ItemDownloadBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemDownloadBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val ctx = h.b.root.context
        h.b.tvName.text = item.name
        h.b.bar.visibility = if (item.state == State.RUNNING) View.VISIBLE else View.GONE
        h.b.bar.progress = item.progress

        val (info, btn) = when (item.state) {
            State.READY -> ctx.getString(R.string.st_ready) to R.string.btn_download
            State.RUNNING -> "${item.progress}%" to R.string.btn_cancel
            State.DONE -> ctx.getString(R.string.st_done) to R.string.btn_install
            State.FAILED -> ctx.getString(R.string.st_failed) to R.string.btn_retry
            State.INVALID -> ctx.getString(R.string.st_invalid) to R.string.btn_retry
        }
        h.b.tvInfo.text = info
        h.b.btnAction.setText(btn)
        h.b.btnAction.setOnClickListener { onAction(item) }
    }
}
