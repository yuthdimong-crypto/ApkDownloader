package com.example.apkdownloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

object ApkScanner {

    private val attrRegex = Regex("""(?:href|src|data-[\w-]+)\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val rawRegex = Regex("""https?://[^\s"'<>\\]+\.apk(?:\?[^\s"'<>\\]*)?""", RegexOption.IGNORE_CASE)

    fun isApkUrl(url: String): Boolean = try {
        URL(url).path.lowercase().endsWith(".apk")
    } catch (e: Exception) {
        false
    }

    fun fileName(url: String): String {
        val last = try {
            URLDecoder.decode(URL(url).path.substringAfterLast('/'), "UTF-8")
        } catch (e: Exception) {
            "download.apk"
        }
        var name = last.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "download.apk" }
        if (!name.lowercase().endsWith(".apk")) name += ".apk"
        return name
    }

    /** ស្កេនទំព័រ HTML ដើម្បីរកតំណ .apk ទាំងអស់ */
    suspend fun scan(pageUrl: String): List<String> = withContext(Dispatchers.IO) {
        val conn = (URL(pageUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
        }
        try {
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            val base = conn.url
            val found = linkedSetOf<String>()

            attrRegex.findAll(html).forEach { m ->
                val raw = m.groupValues[1].replace("&amp;", "&")
                try {
                    found += URL(base, raw).toString()
                } catch (_: Exception) {
                }
            }
            rawRegex.findAll(html).forEach { found += it.value.replace("&amp;", "&") }

            found.filter { isApkUrl(it) }
        } finally {
            conn.disconnect()
        }
    }
}
