package com.example.apkdownloader

enum class State { READY, RUNNING, DONE, FAILED, INVALID }

data class Item(
    val url: String,
    val name: String,
    var downloadId: Long = -1,
    var state: State = State.READY,
    var progress: Int = 0
)
