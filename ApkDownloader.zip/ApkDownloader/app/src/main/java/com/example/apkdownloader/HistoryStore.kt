package com.example.apkdownloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** រក្សាទុកប្រវត្តិទាញយកជា JSON ក្នុង SharedPreferences (មិនបាត់ពេលបិទកម្មវិធី) */
class HistoryStore(ctx: Context) {

    private val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): MutableList<Item> {
        val list = mutableListOf<Item>()
        try {
            val arr = JSONArray(prefs.getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list += Item(
                    url = o.getString("url"),
                    name = o.getString("name"),
                    downloadId = o.optLong("id", -1),
                    state = runCatching { State.valueOf(o.getString("state")) }
                        .getOrDefault(State.READY),
                    progress = o.optInt("progress", 0)
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun save(items: List<Item>) {
        val arr = JSONArray()
        items.take(MAX_ITEMS).forEach {
            arr.put(
                JSONObject()
                    .put("url", it.url)
                    .put("name", it.name)
                    .put("id", it.downloadId)
                    .put("state", it.state.name)
                    .put("progress", it.progress)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "items"
        const val MAX_ITEMS = 200
    }
}
