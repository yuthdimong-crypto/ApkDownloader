package com.example.apkdownloader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.apkdownloader.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var downloader: Downloader
    private lateinit var store: HistoryStore
    private lateinit var adapter: ItemAdapter
    private val items = mutableListOf<Item>()
    private var pollJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        downloader = Downloader(this)
        store = HistoryStore(this)
        restoreHistory()

        adapter = ItemAdapter(items, ::onAction)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.btnGo.setOnClickListener { go() }
        b.btnClear.setOnClickListener { confirmClear() }
        b.etUrl.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) {
                go()
                true
            } else false
        }
    }

    private fun currentKind(): Kind = if (b.rbVideo.isChecked) Kind.VIDEO else Kind.APK

    /** ទាញប្រវត្តិចាស់មកវិញ ហើយធ្វើឱ្យស្ថានភាពត្រូវនឹងការពិត */
    private fun restoreHistory() {
        items.addAll(store.load())
        items.forEach { item ->
            when (item.state) {
                // បានទាញរួច តែឯកសារត្រូវបានលុប → អាចទាញម្តងទៀត
                State.DONE, State.INVALID ->
                    if (!downloader.isAvailable(item)) {
                        item.state = State.READY
                        item.progress = 0
                        item.downloadId = -1
                    }
                // កំពុងទាញពេលបិទកម្មវិធី → សួរ DownloadManager
                State.RUNNING -> downloader.refresh(item)
                else -> Unit
            }
        }
        store.save(items)
    }

    override fun onStart() {
        super.onStart()
        pollJob = lifecycleScope.launch {
            while (isActive) {
                val running = items.filter { it.state == State.RUNNING }
                if (running.isNotEmpty()) {
                    running.forEach { downloader.refresh(it) }
                    refreshUi()
                }
                delay(1000)
            }
        }
    }

    override fun onStop() {
        pollJob?.cancel()
        store.save(items)
        super.onStop()
    }

    private fun refreshUi() {
        adapter.notifyDataSetChanged()
        store.save(items)
    }

    private fun go() {
        var url = b.etUrl.text.toString().trim()
        if (url.isEmpty()) {
            toast(getString(R.string.msg_empty))
            return
        }
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) {
            url = "https://$url"
        }
        val kind = currentKind()

        b.loading.visibility = View.VISIBLE
        b.tvStatus.text = ""
        lifecycleScope.launch {
            try {
                if (ApkScanner.looksDirect(url, kind)) {
                    // តំណឯកសារផ្ទាល់ → ទាញយកភ្លាម
                    val item = addItem(url, kind)
                    if (item.state != State.RUNNING) downloader.enqueue(item)
                    refreshUi()
                } else {
                    val links = ApkScanner.scan(url, kind)
                    if (links.isEmpty()) {
                        b.tvStatus.text = getString(R.string.msg_none)
                    } else {
                        links.forEach { addItem(it, kind) }
                        b.tvStatus.text = getString(R.string.msg_found, links.size)
                        refreshUi()
                    }
                }
            } catch (e: Exception) {
                b.tvStatus.text = getString(R.string.msg_error, e.message ?: e.javaClass.simpleName)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun addItem(url: String, kind: Kind): Item {
        items.firstOrNull { it.url == url && it.kind == kind }?.let { return it }
        val item = Item(url = url, name = ApkScanner.fileName(url, kind), kind = kind)
        items.add(0, item)
        return item
    }

    private fun onAction(item: Item) {
        when (item.state) {
            State.READY, State.FAILED, State.INVALID -> downloader.enqueue(item)
            State.RUNNING -> downloader.cancel(item)
            State.DONE -> if (item.kind == Kind.VIDEO) play(item) else install(item)
        }
        refreshUi()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_clear)
            .setPositiveButton(R.string.yes) { _, _ -> clearHistory() }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    /** លុបប្រវត្តិ និងឯកសារ APK (វីដេអូនៅរក្សាទុកក្នុងថត Movies; ការទាញយកដែលកំពុងដំណើរការមិនត្រូវលុបទេ) */
    private fun clearHistory() {
        val iter = items.iterator()
        while (iter.hasNext()) {
            val item = iter.next()
            if (item.state != State.RUNNING) {
                downloader.deleteApkFile(item)
                iter.remove()
            }
        }
        b.tvStatus.text = ""
        refreshUi()
    }

    private fun play(item: Item) {
        val uri = downloader.uriOf(item)
        if (uri == null) {
            toast(getString(R.string.msg_no_file))
            return
        }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast(getString(R.string.msg_no_file))
        }
    }

    private fun install(item: Item) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast(getString(R.string.msg_allow_install))
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", downloader.fileOf(item))
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(intent)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
