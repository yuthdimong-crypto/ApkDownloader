package com.example.apkdownloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File
import java.util.zip.ZipFile

class Downloader(private val ctx: Context) {

    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** ទីតាំងឯកសារ APK (ក្នុងថតរបស់កម្មវិធី) */
    fun fileOf(item: Item): File =
        File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), item.name)

    fun enqueue(item: Item) {
        // លុបការទាញយកចាស់ (និងឯកសារមិនពេញ) មុនទាញម្តងទៀត
        if (item.downloadId >= 0) dm.remove(item.downloadId)

        val req = DownloadManager.Request(Uri.parse(item.url))
            .setTitle(item.name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .addRequestHeader("User-Agent", USER_AGENT)

        if (item.kind == Kind.VIDEO) {
            // វីដេអូទៅថត Movies/ApkDownloader (មើលឃើញក្នុង Gallery)
            req.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_MOVIES,
                "ApkDownloader/${item.name}"
            )
        } else {
            fileOf(item).delete()
            req.setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, item.name)
        }

        item.downloadId = dm.enqueue(req)
        item.state = State.RUNNING
        item.progress = 0
    }

    fun cancel(item: Item) {
        if (item.downloadId >= 0) dm.remove(item.downloadId)
        item.state = State.READY
        item.progress = 0
        item.downloadId = -1
    }

    /** លុបឯកសារ APK ពីថតកម្មវិធី (វីដេអូមិនត្រូវបានលុបទេ) */
    fun deleteApkFile(item: Item) {
        if (item.kind == Kind.APK) fileOf(item).delete()
    }

    /** តើឯកសារដែលបានទាញរួចនៅមានទេ */
    fun isAvailable(item: Item): Boolean {
        if (item.kind == Kind.APK) return fileOf(item).exists()
        if (item.downloadId < 0) return false
        return dm.query(DownloadManager.Query().setFilterById(item.downloadId))?.use { c ->
            c.moveToFirst() &&
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) ==
                DownloadManager.STATUS_SUCCESSFUL
        } ?: false
    }

    /** Uri សម្រាប់ចាក់វីដេអូដែលបានទាញរួច */
    fun uriOf(item: Item): Uri? =
        if (item.downloadId >= 0) dm.getUriForDownloadedFile(item.downloadId) else null

    /** ធ្វើបច្ចុប្បន្នភាពស្ថានភាពពី DownloadManager */
    fun refresh(item: Item) {
        if (item.state != State.RUNNING || item.downloadId < 0) return
        dm.query(DownloadManager.Query().setFilterById(item.downloadId))?.use { c ->
            if (!c.moveToFirst()) {
                item.state = State.READY
                return
            }
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            if (total > 0) item.progress = (done * 100 / total).toInt()
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    item.progress = 100
                    item.state = when {
                        item.kind == Kind.VIDEO -> State.DONE
                        isValidApk(fileOf(item)) -> State.DONE
                        else -> State.INVALID
                    }
                }
                DownloadManager.STATUS_FAILED -> item.state = State.FAILED
                else -> item.state = State.RUNNING
            }
        }
    }

    /** APK ត្រឹមត្រូវ = ជា ZIP ហើយមាន AndroidManifest.xml */
    private fun isValidApk(f: File): Boolean = try {
        ZipFile(f).use { z -> z.getEntry("AndroidManifest.xml") != null }
    } catch (e: Exception) {
        false
    }
}
