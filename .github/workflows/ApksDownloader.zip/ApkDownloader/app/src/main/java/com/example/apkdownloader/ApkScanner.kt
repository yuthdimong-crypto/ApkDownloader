package com.example.apkdownloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

object ApkScanner {

    private val VIDEO_EXT = listOf(".mp4", ".webm", ".mkv", ".mov", ".avi", ".3gp", ".m4v", ".flv")

    private val attrRegex =
        Regex("""(?:href|src|content|data-[\w-]+)\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val rawRegex = Regex(
        """https?://[^\s"'<>\\]+\.(?:apk|mp4|webm|mkv|mov|avi|3gp|m4v|flv)(?:\?[^\s"'<>\\]*)?""",
        RegexOption.IGNORE_CASE
    )

    /** តំណនេះចប់ដោយនាមត្រកូលឯកសារដែលត្រូវនឹងប្រភេទឬទេ */
    fun matches(url: String, kind: Kind): Boolean = try {
        val path = URL(url).path.lowercase()
        when (kind) {
            Kind.APK -> path.endsWith(".apk")
            Kind.VIDEO -> VIDEO_EXT.any { path.endsWith(it) }
        }
    } catch (e: Exception) {
        false
    }

    fun fileName(url: String, kind: Kind): String {
        val last = try {
            URLDecoder.decode(URL(url).path.substringAfterLast('/'), "UTF-8")
        } catch (e: Exception) {
            ""
        }
        val dot = last.lastIndexOf('.')
        val ext = if (dot >= 0) last.substring(dot).lowercase() else ""
        val base = (if (dot >= 0) last.substring(0, dot) else last)
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .trim('_')
            .ifBlank { "file_${System.currentTimeMillis()}" }
        val safeExt = when (kind) {
            Kind.APK -> ".apk"
            Kind.VIDEO -> if (ext in VIDEO_EXT) ext else ".mp4"
        }
        return base + safeExt
    }

    /** តំណផ្ទាល់ទៅឯកសារ៖ ពិនិត្យនាមត្រកូល ឬប្រភេទខ្លឹមសារ (Content-Type) ពីម៉ាស៊ីនបម្រើ */
    suspend fun looksDirect(url: String, kind: Kind): Boolean = withContext(Dispatchers.IO) {
        if (matches(url, kind)) return@withContext true
        try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 10000
                readTimeout = 10000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
            }
            try {
                val type = (c.contentType ?: "").lowercase()
                when (kind) {
                    Kind.APK -> type.contains("vnd.android.package-archive")
                    Kind.VIDEO -> type.startsWith("video/")
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            false
        }
    }

    /** ស្កេនទំព័រ HTML ដើម្បីរកតំណឯកសារ (APK ឬវីដេអូ) ទាំងអស់ */
    suspend fun scan(pageUrl: String, kind: Kind): List<String> = withContext(Dispatchers.IO) {
        val conn = (URL(pageUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
        }
        try {
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            val base = conn.url
            val found = linkedSetOf<String>()

            attrRegex.findAll(html).forEach { m ->
                val raw = m.groupValues[1].replace("&amp;", "&")
                try {
                    found += URL(base, raw).toString()
                } catch (_: Exception) {
                }
            }
            rawRegex.findAll(html).forEach { found += it.value.replace("&amp;", "&") }

            found.filter { matches(it, kind) }
        } finally {
            conn.disconnect()
        }
    }
}
