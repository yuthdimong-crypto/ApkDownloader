package com.example.apkdownloader

enum class State { READY, RUNNING, DONE, FAILED, INVALID }

enum class Kind { APK, VIDEO }

data class Item(
    val url: String,
    val name: String,
    val kind: Kind = Kind.APK,
    var downloadId: Long = -1,
    var state: State = State.READY,
    var progress: Int = 0
)
